module.exports = {
  future: {
    webpack5: false,
  },
  trailingSlash: true,
}
