---
title: 'Depressed over 5 years'
excerpt: ' I Dont know what i write here'
icon: 'smile'
date: '2021-05-13T19:04:00+0000'
---

### 💔 Introduction

### Just a little explaination

So everything `Started` since i born as a child until today that i was 20 year's old that happend to my whole father family, basically I grew up full of negative thoughts that always surround my mind and heart.

Whole trouble come:

- `Whole Of My Father Family` I started to notice it when I was 6 years old when my mother was threatened with a sword by my grandfather and that day my mother cried and ran for rat poison and tried to drink poison to end her life but failed, i see it with my own eyes - That just a very very begining of my story.
- `Girlfriend` LMAO i never have a GF or Female friend till today i was 20 years old. - nothing to do with this

My escape:

- `Some Of My Mother Family` is an optional array of dependencies. The callback function will be executed once aftr the intial render and every time the value of the dependencies has changed.
- `My Best Friend` All my friends are Male I have no female friends. I never go out in public because I feel very uncomfortable to meet people or stare at everyone. - Covid Protocol ( Stay At Home 🙂)

I have never confide to anyone, including my own parents or brother and even my closest friends, because i know i had no one 😉.


---

### 💔 I can't explain it more because it's too hard to write and hard for my hart

#### I can only write

Still be a `good person` no matter how broken emotional you're 🙂<br>
I can't explain how well I am. Only `certain people` can meet me. Not because I'm arrogant that cause only certain people can meet me but this is according to my heart 🙂

---

### 💔 Last Things

At 20 year's old i owned many Big Cafe on my city also Eirien CEO and i'm not happy with it. Because i still realize that i have `Major Depression` that can't leave.

I Just waiting for :

- End of the world.
- Suicide? because i was think of this things for over 2 years.

### I know all the posts above are broken just enjoy it