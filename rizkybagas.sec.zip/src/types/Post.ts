interface PostData {
  title: string
  excerpt: string
  icon: string
  date: string
  slug: string
  content: string
}

export default PostData
