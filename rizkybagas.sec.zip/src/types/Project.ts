interface ProjectData {
  title: string
  description: string
  image: string
  link: string
  repository: string
}

export default ProjectData
