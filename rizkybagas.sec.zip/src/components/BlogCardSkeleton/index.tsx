export { default } from './BlogCardSkeleton'
