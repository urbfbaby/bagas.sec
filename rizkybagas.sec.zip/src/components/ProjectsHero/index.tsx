export { default } from './ProjectsHero'
