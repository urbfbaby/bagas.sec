export { default } from './ProjectCard'
