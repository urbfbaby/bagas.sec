export { default } from './PostSkeleton'
