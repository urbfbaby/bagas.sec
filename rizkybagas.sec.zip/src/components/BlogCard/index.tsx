export { default } from './BlogCard'
